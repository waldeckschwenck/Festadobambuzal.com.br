// Inicialização do Firebase para o site da Festa Junina do Bambuzal

// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
  authDomain: "festa-junina-bambuzal.firebaseapp.com",
  projectId: "festa-junina-bambuzal",
  storageBucket: "festa-junina-bambuzal.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890abcdef"
};

// Inicializar Firebase
firebase.initializeApp(firebaseConfig);

// Inicializar Firebase Cloud Messaging
const messaging = firebase.messaging();

// Solicitar permissão para notificações
async function requestNotificationPermission() {
  try {
    const permission = await Notification.requestPermission();
    
    if (permission === 'granted') {
      console.log('Permissão de notificação concedida.');
      
      // Obter token do FCM
      const currentToken = await messaging.getToken({
        vapidKey: 'BPxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
      });
      
      if (currentToken) {
        console.log('Token do dispositivo:', currentToken);
        
        // Enviar token para o servidor
        sendTokenToServer(currentToken);
        
        // Inscrever no tópico 'all'
        subscribeToTopic('all');
      } else {
        console.log('Não foi possível obter token.');
        requestNotificationPermission();
      }
    } else {
      console.log('Permissão de notificação negada.');
    }
  } catch (error) {
    console.error('Erro ao solicitar permissão:', error);
  }
}

// Enviar token para o servidor
function sendTokenToServer(token) {
  // Em um ambiente real, você enviaria o token para seu servidor
  console.log('Token enviado para o servidor:', token);
  
  // Armazenar token localmente
  localStorage.setItem('fcmToken', token);
}

// Inscrever em um tópico
function subscribeToTopic(topic) {
  // Em um ambiente real, você enviaria uma solicitação para o servidor
  // para inscrever o token no tópico especificado
  console.log(`Inscrito no tópico: ${topic}`);
}

// Manipulador para mensagens em primeiro plano
messaging.onMessage((payload) => {
  console.log('Mensagem recebida em primeiro plano:', payload);
  
  // Mostrar notificação personalizada
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/images/icon-192x192.png',
    badge: '/images/icon-192x192.png',
    vibrate: [200, 100, 200, 100, 200, 100, 200],
    data: payload.data
  };
  
  if (payload.notification.image) {
    notificationOptions.image = payload.notification.image;
  }
  
  // Verificar se o navegador suporta notificações
  if ('Notification' in window) {
    navigator.serviceWorker.ready.then(registration => {
      registration.showNotification(notificationTitle, notificationOptions);
    });
  }
});

// Manipulador para atualização de token
messaging.onTokenRefresh(async () => {
  try {
    const refreshedToken = await messaging.getToken();
    console.log('Token atualizado:', refreshedToken);
    sendTokenToServer(refreshedToken);
  } catch (error) {
    console.error('Não foi possível atualizar o token:', error);
  }
});

// Verificar se o navegador suporta notificações
if ('Notification' in window) {
  // Verificar se o usuário já deu permissão
  if (Notification.permission === 'granted') {
    requestNotificationPermission();
  } else if (Notification.permission !== 'denied') {
    // Mostrar banner de notificação
    document.addEventListener('DOMContentLoaded', () => {
      const notificationBanner = document.getElementById('notification-banner');
      if (notificationBanner) {
        notificationBanner.style.display = 'block';
        
        // Botão para solicitar permissão
        const enableNotificationsBtn = document.getElementById('enable-notifications');
        if (enableNotificationsBtn) {
          enableNotificationsBtn.addEventListener('click', () => {
            requestNotificationPermission();
            notificationBanner.style.display = 'none';
          });
        }
        
        // Botão para fechar banner
        const closeNotificationBanner = document.getElementById('close-notification-banner');
        if (closeNotificationBanner) {
          closeNotificationBanner.addEventListener('click', () => {
            notificationBanner.style.display = 'none';
          });
        }
      }
    });
  }
}
