// Registrar o Service Worker para PWA
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js').then(function(registration) {
            // Service Worker registrado com sucesso
            console.log('ServiceWorker registrado com sucesso no escopo: ', registration.scope);
            
            // Verificar se o navegador suporta notificações push
            if ('PushManager' in window) {
                console.log('Este navegador suporta notificações push');
            }
        }, function(err) {
            // Falha ao registrar o Service Worker
            console.log('Falha ao registrar o ServiceWorker: ', err);
        });
    });
}

/* Variáveis globais */
let purchaseData = {};
const basePrice = 75.00;
const mercadoPagoLink = "https://mpago.la/2aPtZ41";

/* Inicialização quando o documento estiver pronto */
document.addEventListener('DOMContentLoaded', function() {
    // Configurar o formulário de compra
    const purchaseForm = document.getElementById('purchaseForm');
    if (purchaseForm) {
        purchaseForm.addEventListener('submit', handlePurchaseSubmit);
    }

    // Atualizar o valor total ao mudar a quantidade
    const quantitySelect = document.getElementById('quantity');
    if (quantitySelect) {
        quantitySelect.addEventListener('change', updateTotalAmount);
    }
    
    // Esconder seções de pagamento inicialmente
    const paymentInfo = document.getElementById('paymentInfo');
    const paymentSuccess = document.getElementById('paymentSuccess');
    
    if (paymentInfo) paymentInfo.style.display = 'none';
    if (paymentSuccess) paymentSuccess.style.display = 'none';
    
    // Configurar o menu de navegação
    setupNavigation();
    
    // Inicializar elementos juninos animados
    initJuninoElements();
    
    // Ativar o menu responsivo
    setupResponsiveMenu();
    
    // Verificar se o app já está instalado
    checkInstallStatus();
});

/* Função para lidar com o envio do formulário de compra */
function handlePurchaseSubmit(e) {
    e.preventDefault();
    
    // Coletar dados do formulário
    const form = e.target;
    purchaseData = {
        name: form.name.value,
        email: form.email.value,
        phone: form.phone.value,
        quantity: parseInt(form.quantity.value),
        totalAmount: basePrice * parseInt(form.quantity.value),
        paymentId: generatePaymentId()
    };
    
    // Redirecionar para o checkout do Mercado Pago
    redirectToMercadoPagoCheckout();
}

/* Função para gerar um ID de pagamento único */
function generatePaymentId() {
    const timestamp = new Date().getTime();
    const random = Math.floor(Math.random() * 1000);
    return `BAMBUZAL2025-${timestamp}-${random}`;
}

/* Função para redirecionar para o checkout do Mercado Pago */
function redirectToMercadoPagoCheckout() {
    // Mostrar a seção de pagamento com mensagem de redirecionamento
    const ticketForm = document.getElementById('ticketForm');
    const paymentInfo = document.getElementById('paymentInfo');
    
    if (ticketForm) ticketForm.style.display = 'none';
    if (paymentInfo) paymentInfo.style.display = 'block';
    
    // Atualizar o valor total
    const totalAmountElement = document.getElementById('totalAmount');
    if (totalAmountElement) {
        totalAmountElement.textContent = `R$ ${purchaseData.totalAmount.toFixed(2)}`;
    }
    
    // Configurar o botão de redirecionamento com o link do Mercado Pago
    const redirectButton = document.getElementById('redirectButton');
    if (redirectButton) {
        // Usar o link direto do Mercado Pago
        redirectButton.href = mercadoPagoLink;
        
        // Adicionar evento de clique para garantir que o link abra em nova aba
        redirectButton.addEventListener('click', function(e) {
            e.preventDefault();
            window.open(mercadoPagoLink, '_blank');
        });
    }
    
    // Redirecionar automaticamente após 2 segundos
    setTimeout(function() {
        // Usar método mais confiável para abrir em nova aba
        const newWindow = window.open(mercadoPagoLink, '_blank');
        
        // Verificar se a janela foi bloqueada pelo navegador
        if (!newWindow || newWindow.closed || typeof newWindow.closed=='undefined') {
            // Se foi bloqueada, mostrar mensagem para clicar manualmente
            console.log("Pop-up bloqueado. Por favor, clique no botão para continuar.");
        }
    }, 1500);
}

/* Função para atualizar o valor total com base na quantidade */
function updateTotalAmount() {
    const quantity = parseInt(document.getElementById('quantity').value);
    const totalAmount = basePrice * quantity;
    
    // Se já estiver na tela de pagamento, atualizar o valor exibido
    const totalAmountElement = document.getElementById('totalAmount');
    if (totalAmountElement) {
        totalAmountElement.textContent = `R$ ${totalAmount.toFixed(2)}`;
    }
}

/* Função para configurar o menu de navegação */
function setupNavigation() {
    // Adicionar navegação suave para links de âncora
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // Rolar suavemente até o elemento
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // Atualizar classe ativa no menu
                document.querySelectorAll('.nav-menu a').forEach(item => {
                    item.classList.remove('active');
                });
                this.classList.add('active');
                
                // Fechar menu móvel se estiver aberto
                const navMenu = document.getElementById('navMenu');
                if (navMenu && navMenu.classList.contains('active') && window.innerWidth <= 768) {
                    navMenu.classList.remove('active');
                }
            }
        });
    });
    
    // Atualizar menu ativo durante a rolagem
    window.addEventListener('scroll', function() {
        const scrollPosition = window.scrollY;
        
        // Obter todas as seções
        const sections = document.querySelectorAll('section, header');
        
        // Verificar qual seção está visível
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (sectionId && scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                // Remover classe ativa de todos os links
                document.querySelectorAll('.nav-menu a').forEach(item => {
                    item.classList.remove('active');
                });
                
                // Adicionar classe ativa ao link correspondente
                const activeLink = document.querySelector(`.nav-menu a[href="#${sectionId}"]`);
                if (activeLink) {
                    activeLink.classList.add('active');
                }
            }
        });
    });
}

/* Função para configurar o menu responsivo */
function setupResponsiveMenu() {
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.getElementById('navMenu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
}

/* Função para inicializar elementos juninos animados */
function initJuninoElements() {
    // Mostrar fogueira em telas maiores
    const fogueira = document.querySelector('.fogueira');
    if (fogueira && window.innerWidth > 768) {
        fogueira.style.display = 'block';
    }
    
    // Mostrar balões com atraso
    setTimeout(() => {
        document.querySelectorAll('.balao').forEach(balao => {
            balao.style.display = 'block';
        });
    }, 2000);
    
    // Adicionar mais balões aleatoriamente
    setInterval(() => {
        if (Math.random() > 0.7 && window.innerWidth > 768) {
            createRandomBalao();
        }
    }, 8000);
}

/* Função para criar balões aleatórios */
function createRandomBalao() {
    const colors = ['#d35400', '#2c8c3c', '#f39c12'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    const balao = document.createElement('div');
    balao.className = 'balao';
    balao.style.right = Math.floor(Math.random() * 20) + '%';
    balao.style.backgroundColor = randomColor;
    balao.style.display = 'block';
    
    // Adicionar pseudo-elementos via CSS inline
    balao.innerHTML = `
        <style>
            .balao:before {
                content: '';
                position: absolute;
                bottom: -10px;
                left: 15px;
                width: 10px;
                height: 15px;
                background-color: ${randomColor};
                border-radius: 0 0 5px 5px;
            }
            .balao:after {
                content: '';
                position: absolute;
                bottom: -20px;
                left: 18px;
                width: 4px;
                height: 20px;
                background-color: #d35400;
            }
        </style>
    `;
    
    document.body.appendChild(balao);
    
    // Remover o balão após a animação
    setTimeout(() => {
        if (balao && balao.parentNode) {
            balao.parentNode.removeChild(balao);
        }
    }, 15000);
}

/* Funções para PWA */
let deferredPrompt;

// Verificar se o app já está instalado
function checkInstallStatus() {
    // Verificar se o app está sendo executado em modo standalone (instalado)
    if (window.matchMedia('(display-mode: standalone)').matches) {
        console.log('Aplicativo já está instalado');
        // Esconder o botão de instalação se existir
        const installButton = document.getElementById('installApp');
        if (installButton) {
            installButton.style.display = 'none';
        }
    } else {
        // Mostrar o botão de instalação
        showInstallButton();
    }
}

// Mostrar botão de instalação
function showInstallButton() {
    // Capturar o evento beforeinstallprompt
    window.addEventListener('beforeinstallprompt', (e) => {
        // Prevenir o comportamento padrão
        e.preventDefault();
        // Armazenar o evento para uso posterior
        deferredPrompt = e;
        
        // Criar botão de instalação se não existir
        if (!document.getElementById('installApp')) {
            const installButton = document.createElement('button');
            installButton.id = 'installApp';
            installButton.className = 'install-button';
            installButton.innerHTML = '<i class="fas fa-download"></i> Instalar App';
            
            // Adicionar evento de clique
            installButton.addEventListener('click', installApp);
            
            // Adicionar ao DOM
            document.body.appendChild(installButton);
        }
    });
}

// Função para instalar o app
function installApp() {
    if (!deferredPrompt) return;
    
    // Mostrar o prompt de instalação
    deferredPrompt.prompt();
    
    // Aguardar a resposta do usuário
    deferredPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
            console.log('Usuário aceitou a instalação');
            // Esconder o botão de instalação
            const installButton = document.getElementById('installApp');
            if (installButton) {
                installButton.style.display = 'none';
            }
        } else {
            console.log('Usuário recusou a instalação');
        }
        // Limpar a referência
        deferredPrompt = null;
    });
}

// Solicitar permissão para notificações
function requestNotificationPermission() {
    if ('Notification' in window) {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                console.log('Permissão para notificações concedida');
                // Aqui você pode mostrar uma notificação de teste
                showTestNotification();
            }
        });
    }
}

// Mostrar uma notificação de teste
function showTestNotification() {
    if ('Notification' in window && Notification.permission === 'granted') {
        navigator.serviceWorker.ready.then(registration => {
            registration.showNotification('Festa Junina do Bambuzal', {
                body: 'Obrigado por se inscrever nas notificações! Você receberá atualizações sobre a festa.',
                icon: '/images/icon-192x192.png',
                badge: '/images/icon-192x192.png'
            });
        });
    }
}
