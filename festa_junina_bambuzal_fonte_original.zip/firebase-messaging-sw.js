// Firebase Cloud Messaging Service Worker para a Festa Junina do Bambuzal

importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-messaging-compat.js');

// Configuração do Firebase
firebase.initializeApp({
  apiKey: "AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
  authDomain: "festa-junina-bambuzal.firebaseapp.com",
  projectId: "festa-junina-bambuzal",
  storageBucket: "festa-junina-bambuzal.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890abcdef"
});

const messaging = firebase.messaging();

// Manipulador para mensagens em background
messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Recebida mensagem em background:', payload);
  
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/images/icon-192x192.png',
    badge: '/images/icon-192x192.png',
    vibrate: [200, 100, 200, 100, 200, 100, 200],
    tag: 'festa-junina-notification',
    data: payload.data
  };
  
  if (payload.notification.image) {
    notificationOptions.image = payload.notification.image;
  }
  
  self.registration.showNotification(notificationTitle, notificationOptions);
});

// Manipulador para clique na notificação
self.addEventListener('notificationclick', (event) => {
  console.log('[firebase-messaging-sw.js] Clique na notificação', event);
  
  event.notification.close();
  
  // Navegar para a página principal quando a notificação for clicada
  const urlToOpen = new URL('/', self.location.origin).href;
  
  const promiseChain = clients.matchAll({
    type: 'window',
    includeUncontrolled: true
  })
  .then((windowClients) => {
    // Verificar se já existe uma janela aberta
    for (let i = 0; i < windowClients.length; i++) {
      const client = windowClients[i];
      if (client.url === urlToOpen && 'focus' in client) {
        return client.focus();
      }
    }
    
    // Se não existir, abrir uma nova janela
    if (clients.openWindow) {
      return clients.openWindow(urlToOpen);
    }
  });
  
  event.waitUntil(promiseChain);
});
