/* Variáveis globais */
let purchaseData = {};
const basePrice = 75.00;

/* Inicialização quando o documento estiver pronto */
document.addEventListener('DOMContentLoaded', function() {
    // Configurar o formulário de compra
    const purchaseForm = document.getElementById('purchaseForm');
    if (purchaseForm) {
        purchaseForm.addEventListener('submit', handlePurchaseSubmit);
    }

    // Atualizar o valor total ao mudar a quantidade
    const quantitySelect = document.getElementById('quantity');
    if (quantitySelect) {
        quantitySelect.addEventListener('change', updateTotalAmount);
    }
    
    // Esconder seções de pagamento inicialmente
    document.getElementById('paymentInfo').style.display = 'none';
    document.getElementById('paymentSuccess').style.display = 'none';
});

/* Função para lidar com o envio do formulário de compra */
function handlePurchaseSubmit(e) {
    e.preventDefault();
    
    // Coletar dados do formulário
    const form = e.target;
    purchaseData = {
        name: form.name.value,
        email: form.email.value,
        phone: form.phone.value,
        quantity: parseInt(form.quantity.value),
        totalAmount: basePrice * parseInt(form.quantity.value),
        paymentId: generatePaymentId()
    };
    
    // Redirecionar para o checkout do Mercado Pago
    redirectToMercadoPagoCheckout();
}

/* Função para gerar um ID de pagamento único */
function generatePaymentId() {
    const timestamp = new Date().getTime();
    const random = Math.floor(Math.random() * 1000);
    return `BAMBUZAL2025-${timestamp}-${random}`;
}

/* Função para redirecionar para o checkout do Mercado Pago */
function redirectToMercadoPagoCheckout() {
    // Mostrar a seção de pagamento com mensagem de redirecionamento
    document.getElementById('ticketForm').style.display = 'none';
    document.getElementById('paymentInfo').style.display = 'block';
    
    // Atualizar o valor total
    document.getElementById('totalAmount').textContent = `R$ ${purchaseData.totalAmount.toFixed(2)}`;
    
    // Criar URL para o Mercado Pago com os parâmetros necessários
    // Esta é uma URL direta para a página de pagamento do Mercado Pago
    // O organizador pode facilmente substituir o "seu-usuario" pelo nome de usuário real do Mercado Pago
    const title = encodeURIComponent(`Ingresso Festa Junina do Bambuzal - ${purchaseData.quantity} ${purchaseData.quantity > 1 ? 'ingressos' : 'ingresso'}`);
    const price = purchaseData.totalAmount;
    const quantity = purchaseData.quantity;
    const buyerEmail = encodeURIComponent(purchaseData.email);
    const buyerName = encodeURIComponent(purchaseData.name);
    
    // URL direta para o Mercado Pago Link de Pagamento
    // Esta URL é mais estável e não depende de preferências que podem expirar
    const checkoutURL = `https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=1234567890-1234567890123-052425-abcdefghijklmnopqrst-123456789`;
    
    // URL alternativa para o formulário de pagamento do Mercado Pago
    // Esta URL pode ser usada como fallback se a primeira não funcionar
    const fallbackURL = `https://www.mercadopago.com.br/payment-link/v1/redirect?preference-id=1234567890&creator_id=1234567890&payment_method=all&installments=1`;
    
    // Atualizar o conteúdo da seção de pagamento
    const paymentInfoSection = document.getElementById('paymentInfo');
    paymentInfoSection.innerHTML = `
        <h2>Redirecionando para Pagamento</h2>
        <p><strong>Valor Total:</strong> <span id="totalAmount">R$ ${purchaseData.totalAmount.toFixed(2)}</span></p>
        <p>Você será redirecionado para o site do Mercado Pago para finalizar seu pagamento com segurança.</p>
        <p>Após a confirmação do pagamento, você receberá seu ingresso por e-mail.</p>
        
        <div class="redirect-container">
            <p>Se o redirecionamento não ocorrer automaticamente, clique no botão abaixo:</p>
            <a href="${checkoutURL}" class="btn" id="redirectButton" target="_blank">Ir para Pagamento</a>
        </div>
        
        <div class="redirect-container" style="margin-top: 20px;">
            <p>Se o link acima não funcionar, tente este link alternativo:</p>
            <a href="${fallbackURL}" class="btn" style="background-color: #4CAF50;" target="_blank">Link Alternativo de Pagamento</a>
        </div>
        
        <div class="confirmation-steps">
            <h3>Próximos passos:</h3>
            <ol>
                <li>Você será redirecionado para o site do Mercado Pago</li>
                <li>Escolha sua forma de pagamento preferida (PIX, cartão, etc.)</li>
                <li>Complete as informações solicitadas</li>
                <li>Confirme o pagamento</li>
                <li>Após a confirmação, você receberá seu ingresso por e-mail</li>
                <li>Apresente o ingresso (impresso ou no celular) no dia do evento</li>
            </ol>
        </div>
    `;
    
    // Abrir o link em uma nova aba - método mais confiável para redirecionamento
    window.open(checkoutURL, '_blank');
    
    // Adicionar evento de clique ao botão de redirecionamento como fallback
    setTimeout(() => {
        const redirectButton = document.getElementById('redirectButton');
        if (redirectButton) {
            // Adicionar evento de clique para garantir que o botão funcione
            redirectButton.addEventListener('click', function(e) {
                // Impedir comportamento padrão para garantir que abra em nova aba
                e.preventDefault();
                // Abrir em nova aba
                window.open(checkoutURL, '_blank');
            });
        }
    }, 1000);
}

/* Função para atualizar o valor total com base na quantidade */
function updateTotalAmount() {
    const quantity = parseInt(document.getElementById('quantity').value);
    const totalAmount = basePrice * quantity;
    
    // Se já estiver na tela de pagamento, atualizar o valor exibido
    const totalAmountElement = document.getElementById('totalAmount');
    if (totalAmountElement) {
        totalAmountElement.textContent = `R$ ${totalAmount.toFixed(2)}`;
    }
}
